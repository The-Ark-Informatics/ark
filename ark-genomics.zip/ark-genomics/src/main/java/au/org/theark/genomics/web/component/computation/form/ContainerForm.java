package au.org.theark.genomics.web.component.computation.form;

import org.apache.wicket.model.CompoundPropertyModel;

import au.org.theark.core.web.form.AbstractContainerForm;
import au.org.theark.genomics.model.vo.ComputationVo;

public class ContainerForm extends AbstractContainerForm<ComputationVo> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContainerForm(String id, CompoundPropertyModel<ComputationVo> cpmModel) {
		super(id, cpmModel);
		// TODO Auto-generated constructor stub
	}
}

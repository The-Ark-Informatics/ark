package au.org.theark.genomics.web.component.datacenter.form;

import org.apache.wicket.model.CompoundPropertyModel;
import au.org.theark.core.web.form.AbstractContainerForm;
import au.org.theark.genomics.model.vo.DataCenterVo;

public class QueryContainerForm extends AbstractContainerForm<DataCenterVo> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QueryContainerForm(String id, CompoundPropertyModel<DataCenterVo> cpmModel) {
		super(id, cpmModel);
		// TODO Auto-generated constructor stub
	}

}

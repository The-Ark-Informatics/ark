package au.org.theark.genomics.web.component.datacenter.form;

import org.apache.wicket.model.CompoundPropertyModel;

import au.org.theark.core.web.form.AbstractContainerForm;
import au.org.theark.genomics.model.vo.DataSourceVo;

public class SourceContainerForm extends AbstractContainerForm<DataSourceVo> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SourceContainerForm(String id, CompoundPropertyModel<DataSourceVo> cpmModel) {
		super(id, cpmModel);
		// TODO Auto-generated constructor stub
	}

}

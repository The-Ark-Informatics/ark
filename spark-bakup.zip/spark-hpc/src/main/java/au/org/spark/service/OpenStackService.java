package au.org.spark.service;

import java.util.List;

public interface OpenStackService {
	
	public List<String> listContainers();
	
}
